advancement revoke @s only apocalypse:got_hurt
execute if score current_difficulty gbz.difficulty matches 1 if predicate apocalypse:minor_infection_easy run execute as @s at @s run function apocalypse:minor_infection
execute if score current_difficulty gbz.difficulty matches 2 if predicate apocalypse:minor_infection_normal run execute as @s at @s run function apocalypse:minor_infection
execute if score current_difficulty gbz.difficulty matches 3.. if predicate apocalypse:minor_infection_hard run execute as @s at @s run function apocalypse:minor_infection
