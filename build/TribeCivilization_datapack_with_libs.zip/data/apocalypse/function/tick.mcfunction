# Difficulty Trigger Command
scoreboard players enable @a gbz.difficulty
execute as @a[scores={gbz.difficulty=1..}] run function apocalypse:setting_difficulty/setting
scoreboard players reset @a[scores={gbz.difficulty=1..}] gbz.difficulty

# Zombie Spawning
execute as @e[type=#apocalypse:zombie_replaceable,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/zombie/spawn_zombie
execute as @e[type=drowned,tag=!gbz.zombie,sort=random] at @s run function apocalypse:spawn/drowned/spawn_drowned_conversion
execute as @e[type=#apocalypse:drowned_replaceable,tag=!gbz.zombie,sort=random] at @s run function apocalypse:spawn/drowned/spawn_drowned_natural
execute unless score animal_toggle config.gbz matches 1 as @e[type=chicken,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/animal/spawn_chicken
execute unless score animal_toggle config.gbz matches 1 as @e[type=pig,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/animal/spawn_pig
execute unless score animal_toggle config.gbz matches 1 as @e[type=sheep,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/animal/spawn_sheep
execute unless score animal_toggle config.gbz matches 1 as @e[type=cow,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/animal/spawn_cow
execute unless score animal_toggle config.gbz matches 1 as @e[type=horse,tag=!gbz.zombie,sort=random,predicate=apocalypse:overworld] at @s run function apocalypse:spawn/animal/spawn_horse

# Illager Skirmisher Spawning
execute if score gbz.illager_spawner gbz.illager_spawner matches 0 run function apocalypse:spawn/skirmisher/can_spawn
scoreboard players remove gbz.illager_spawner gbz.illager_spawner 1

#Zombie Animal Death
execute as @e[type=#apocalypse:zombie_animal_total] at @s run function apocalypse:zombie_abilities/kill_brain

#Player Zombie Spawning
execute as @a[scores={gbz.player_death=1..}] at @s run function apocalypse:spawn/player_zombie/spawn

# Zombie Loop
execute as @e[type=#apocalypse:is_zombie] at @s run function apocalypse:zombie_loop


