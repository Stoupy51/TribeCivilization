# executing AS and AT the executing zombie on fire
fill ~ ~ ~ ~ ~ ~ fire replace #apocalypse:fire_replaceable
effect give @s instant_health 1 0 true
