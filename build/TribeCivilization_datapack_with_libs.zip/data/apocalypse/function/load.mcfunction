
schedule function apocalypse:generic_schedual_loop 22s replace
schedule function apocalypse:zombie_attributes_loop 2s replace
schedule function apocalypse:setting_difficulty/message 3s replace

# Misc Scoreboards
scoreboard objectives add gbz.player_death deathCount
scoreboard players add @a gbz.player_death 0

scoreboard objectives add gbz.random_roll dummy
scoreboard objectives add gbz.temp dummy
scoreboard objectives add gbz.location dummy
scoreboard objectives add gbz.day_time dummy
scoreboard objectives add gbz.illager_spawner dummy
scoreboard players add gbz.illager_spawner gbz.illager_spawner 0

# Datapack Detect Scoreboards
scoreboard objectives add gb.datapack_detect dummy
scoreboard players set gbz gb.datapack_detect 1
scoreboard players add gbg gb.datapack_detect 0
scoreboard players add modern_guns gb.datapack_detect 0
scoreboard players add pipe_guns gb.datapack_detect 0
scoreboard players add power_armor gb.datapack_detect 0

# Builder/Miner Scoreboards
scoreboard objectives add PX1 dummy
scoreboard objectives add PX2 dummy
scoreboard objectives add PY1 dummy
scoreboard objectives add PY2 dummy
scoreboard objectives add PZ1 dummy
scoreboard objectives add PZ2 dummy
scoreboard objectives add PTMP dummy

scoreboard objectives add P_DIRECTION dummy
scoreboard objectives add ABOVE_BELOW dummy

# Spawning Scoreboard
scoreboard objectives add gbz.zombie_spawning_loop dummy
scoreboard players add drowned_natural gbz.zombie_spawning_loop 0
scoreboard players add drowned gbz.zombie_spawning_loop 0
scoreboard players add chicken gbz.zombie_spawning_loop 0
scoreboard players add pig gbz.zombie_spawning_loop 0
scoreboard players add sheep gbz.zombie_spawning_loop 0
scoreboard players add cow gbz.zombie_spawning_loop 0
scoreboard players add horse gbz.zombie_spawning_loop 0

# Zombie Ability Scoreboards
scoreboard objectives add gbz.ability_timer dummy
scoreboard objectives add gbz.zombie.projectile_damage dummy
scoreboard objectives add gbz.zombie.projectile_distance dummy
scoreboard objectives add gbz.zombie.projectile_type dummy
scoreboard objectives add gbz.zombie.projectile_fire_rate dummy
scoreboard objectives add gbz.zombie.current_raycast_distance dummy

# Difficulty Scoreboards
scoreboard objectives add gbz.difficulty trigger
scoreboard players add current_difficulty gbz.difficulty 0

# Config Scoreboard
scoreboard objectives add config.gbz dummy
scoreboard players add swarm_toggle config.gbz 0
scoreboard players add dj_toggle config.gbz 0
scoreboard players add zombie_villager_toggle config.gbz 0
scoreboard players add animal_toggle config.gbz 0
scoreboard players add builder_toggle config.gbz 0
scoreboard players add miner_toggle config.gbz 0
scoreboard players add acid_spitter_toggle config.gbz 0
scoreboard players add acid_spewer_toggle config.gbz 0
scoreboard players add nurse_toggle config.gbz 0
scoreboard players add psycho_toggle config.gbz 0
scoreboard players add scorched_toggle config.gbz 0
scoreboard players add player_zombies_toggle config.gbz 0
scoreboard players add skirmisher_toggle config.gbz 0

# Zombie Teams
team add gbz_zombie
team modify gbz_zombie prefix {"text":"☠ "}
team modify gbz_zombie suffix {"text":" ☠"}
team modify gbz_zombie color dark_green
team add gbz_player_zombie
team modify gbz_player_zombie prefix {"text":"☠ "}
team modify gbz_player_zombie suffix {"text":" Zombie ☠"}
team modify gbz_player_zombie color dark_green
team add gbz_enraged_zombie
team modify gbz_enraged_zombie prefix {"text":"☠ Enraged "}
team modify gbz_enraged_zombie suffix {"text":" ☠"}
team modify gbz_enraged_zombie color red
team add gbz_energized_zombie
team modify gbz_energized_zombie prefix {"text":"☠ Energized "}
team modify gbz_energized_zombie suffix {"text":" ☠"}
team modify gbz_energized_zombie color gold
team add gbz_armored_zombie
team modify gbz_armored_zombie prefix {"text":"☠ Armored "}
team modify gbz_armored_zombie suffix {"text":" ☠"}
team modify gbz_armored_zombie color dark_aqua
team add gbz_weaponed_zombie
team modify gbz_weaponed_zombie prefix {"text":"☠ Weaponed "}
team modify gbz_weaponed_zombie suffix {"text":" ☠"}
team modify gbz_weaponed_zombie color dark_blue
