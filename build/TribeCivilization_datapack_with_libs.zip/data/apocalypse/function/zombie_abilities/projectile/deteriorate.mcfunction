## Deterioration fill command list
#Visual Particles and Sound Effect
particle sneeze ~ ~ ~ 0.1 0.1 0.1 0.03 5
playsound item.wolf_armor.crack hostile @a ~ ~ ~ 1 0.75
playsound entity.turtle.egg_crack hostile @a ~ ~ ~ 1 0.5
#Whatever block is hit, it is changed to it's deteriorated form
fill ~ ~ ~ ~ ~ ~ cracked_stone_bricks replace stone_bricks
fill ~ ~ ~ ~ ~ ~ cracked_stone_bricks replace stone_brick_slab
fill ~ ~ ~ ~ ~ ~ cracked_deepslate_bricks replace deepslate_bricks
fill ~ ~ ~ ~ ~ ~ cracked_deepslate_bricks replace deepslate_brick_slab
fill ~ ~ ~ ~ ~ ~ cobbled_deepslate replace polished_deepslate
fill ~ ~ ~ ~ ~ ~ cobbled_deepslate replace polished_deepslate_slab
fill ~ ~ ~ ~ ~ ~ cracked_deepslate_tiles replace deepslate_tiles
fill ~ ~ ~ ~ ~ ~ cracked_deepslate_tiles replace deepslate_tile_slab
fill ~ ~ ~ ~ ~ ~ stone replace smooth_stone
fill ~ ~ ~ ~ ~ ~ stone replace smooth_stone_slab
fill ~ ~ ~ ~ ~ ~ andesite replace polished_andesite
fill ~ ~ ~ ~ ~ ~ andesite replace polished_andesite_slab
fill ~ ~ ~ ~ ~ ~ granite replace polished_granite
fill ~ ~ ~ ~ ~ ~ granite replace polished_granite_slab
fill ~ ~ ~ ~ ~ ~ diorite replace polished_diorite
fill ~ ~ ~ ~ ~ ~ diorite replace polished_diorite_slab
fill ~ ~ ~ ~ ~ ~ tuff replace polished_tuff
fill ~ ~ ~ ~ ~ ~ tuff replace polished_tuff_slab
fill ~ ~ ~ ~ ~ ~ tuff replace tuff_bricks
fill ~ ~ ~ ~ ~ ~ tuff replace tuff_brick_slab
fill ~ ~ ~ ~ ~ ~ packed_mud replace mud_bricks
fill ~ ~ ~ ~ ~ ~ packed_mud replace mud_brick_slab
fill ~ ~ ~ ~ ~ ~ sandstone replace smooth_sandstone
fill ~ ~ ~ ~ ~ ~ sandstone replace smooth_sandstone_slab
fill ~ ~ ~ ~ ~ ~ sandstone replace cut_sandstone
fill ~ ~ ~ ~ ~ ~ sandstone replace cut_sandstone_slab
fill ~ ~ ~ ~ ~ ~ red_sandstone replace smooth_red_sandstone
fill ~ ~ ~ ~ ~ ~ red_sandstone replace smooth_red_sandstone_slab
fill ~ ~ ~ ~ ~ ~ red_sandstone replace cut_red_sandstone
fill ~ ~ ~ ~ ~ ~ red_sandstone replace cut_red_sandstone_slab
fill ~ ~ ~ ~ ~ ~ cracked_nether_bricks replace nether_bricks
fill ~ ~ ~ ~ ~ ~ cracked_nether_bricks replace nether_brick_slab
fill ~ ~ ~ ~ ~ ~ blackstone replace polished_blackstone
fill ~ ~ ~ ~ ~ ~ blackstone replace polished_blackstone_slab
fill ~ ~ ~ ~ ~ ~ blackstone replace polished_blackstone_bricks
fill ~ ~ ~ ~ ~ ~ blackstone replace polished_blackstone_brick_slab
fill ~ ~ ~ ~ ~ ~ coarse_dirt replace bone_block
fill ~ ~ ~ ~ ~ ~ basalt replace polished_basalt


