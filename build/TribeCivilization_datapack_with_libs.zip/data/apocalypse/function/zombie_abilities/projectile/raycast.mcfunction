## Zombie Projectile Raycast
scoreboard players add @s gbz.zombie.current_raycast_distance 1

# Displaying Particles
execute if score @s gbz.zombie.projectile_type matches 1 run particle minecraft:sneeze ^ ^ ^ 0 0 0 0 2
execute if score @s gbz.zombie.projectile_type matches 2 run particle dust{color:[0.125,0.361,0.388],scale:1} ^ ^ ^ 0 0 0 0 1 normal
execute if score @s gbz.zombie.projectile_type matches 2 run particle dust{color:[0.259,0.612,0.655],scale:1} ^ ^ ^ 0 0 0 0 1 normal
execute if score @s gbz.zombie.projectile_type matches 2 run particle dust{color:[0.110,0.537,0.592],scale:1} ^ ^ ^ 0 0 0 0 1 normal
execute if score @s gbz.zombie.projectile_type matches 2 run particle dust{color:[0.122,0.494,0.275],scale:1} ^ ^ ^ 0 0 0 0 1 normal

# Hurting Target
execute if entity @e[limit=1,type=player,dx=0] run scoreboard players add @s gbz.zombie.current_raycast_distance 3000
execute if entity @e[limit=1,type=#apocalypse:zombie_targets,dx=0] run function apocalypse:zombie_abilities/projectile/shot

# Deteriorating Block
execute if block ^ ^ ^ #apocalypse:deteriorable if score current_difficulty gbz.difficulty matches 4.. if predicate apocalypse:deteriorate_chance run function apocalypse:zombie_abilities/projectile/deteriorate

# Calling Raycast Again
execute if score @s gbz.zombie.current_raycast_distance <= @s gbz.zombie.projectile_distance if block ^ ^ ^ #apocalypse:air unless entity @e[type=#apocalypse:zombie_targets,dx=0] positioned ^ ^ ^0.1 rotated ~ ~ run function apocalypse:zombie_abilities/projectile/raycast

# Ending Raycast
execute if score @s gbz.zombie.current_raycast_distance >= @s gbz.zombie.projectile_distance run scoreboard players reset @s gbz.zombie.current_raycast_distance
execute if entity @e[type=#apocalypse:zombie_targets,dx=0] run scoreboard players reset @s gbz.zombie.current_raycast_distance
execute unless block ^ ^ ^ #apocalypse:air run scoreboard players reset @s gbz.zombie.current_raycast_distance


