# Damaging Player
attribute @e[limit=1,type=player,dx=0] knockback_resistance modifier add apocalypse:projectile_knockback_resistance 1 add_value
execute if score @s gbz.zombie.projectile_damage matches 1 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 1 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 2 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 2 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 3 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 3 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 4 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 4 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 5 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 5 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 6 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 6 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 7 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 7 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 8 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 8 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 9 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 9 apocalypse:projectile by @s
execute if score @s gbz.zombie.projectile_damage matches 10 run damage @e[limit=1,type=#apocalypse:zombie_targets,dx=0] 10 apocalypse:projectile by @s

# Status Effects
execute if score @s gbz.zombie.projectile_type matches 2 run effect give @e[limit=1,type=#apocalypse:zombie_targets,dx=0] mining_fatigue 14 0 false

# Sounds
playsound entity.player.hurt_sweet_berry_bush player @s[type=player] ~ ~ ~ 1 1
attribute @e[limit=1,type=player,dx=0] knockback_resistance modifier remove apocalypse:projectile_knockback_resistance
