## Zombie Projectile Shoot
scoreboard players operation @s gbz.ability_timer = @s gbz.zombie.projectile_fire_rate
playsound minecraft:entity.player.splash.high_speed player @a ~ ~ ~ 1 2
playsound minecraft:entity.player.splash player @a ~ ~ ~ 1 2

function apocalypse:zombie_abilities/projectile/raycast
