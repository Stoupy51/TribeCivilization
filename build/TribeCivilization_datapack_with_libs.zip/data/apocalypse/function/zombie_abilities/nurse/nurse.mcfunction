scoreboard players set @s gbz.ability_timer 60
execute as @e[type=zombie,distance=..4,tag=!gbz.nurse,limit=2,sort=nearest] at @s run function apocalypse:zombie_abilities/nurse/as_zombie
playsound item.bottle.fill hostile @a ~ ~ ~ 1 2
playsound item.bottle.fill hostile @a ~ ~ ~ 1 0.5



