#executing AS and At the zombie being healed
effect give @s instant_damage 1 0
particle witch ~ ~1 ~ 0 0 0 1 5 normal
particle enchanted_hit ~ ~1 ~ 0 0 0 0.2 5 normal


