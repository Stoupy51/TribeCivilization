# All Zombie Animal Brains
scoreboard players set has_body gbz.temp 0
execute as @s[type=husk,tag=zombie_animal_brain] on vehicle run scoreboard players set has_body gbz.temp 1
execute if score has_body gbz.temp matches 1 run tag @s add gbz.has_body
kill @s[type=husk,tag=zombie_animal_brain,tag=!gbz.has_body]
tag @s[type=husk,tag=zombie_animal_brain] remove gbz.has_body

# All Zombie Animal Bodies
scoreboard players set has_passengers gbz.temp 0
execute as @s[type=#apocalypse:zombie_animal,tag=zombie_animal] on passengers run scoreboard players set has_passengers gbz.temp 1
execute if score has_passengers gbz.temp matches 1 run tag @s add gbz.has_brain
kill @s[type=#apocalypse:zombie_animal,tag=zombie_animal,tag=!gbz.has_brain]
tag @s[type=#apocalypse:zombie_animal,tag=zombie_animal] remove gbz.has_brain
