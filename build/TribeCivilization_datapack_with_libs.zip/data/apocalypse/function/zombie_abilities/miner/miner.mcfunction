
# ~-1 ~ ~ West
# ~1 ~ ~ East
# ~ ~ ~-1 North
# ~ ~ ~1 South

# 1 North
# 2 North East
# 3 East
# 4 South East
# 5 South
# 6 South West
# 7 West
# 8 North West

#miner
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~ ~2 ~-1 #apocalypse:breakable run setblock ~ ~2 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~1 ~2 ~-1 #apocalypse:breakable run setblock ~1 ~2 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 1 if block ~-1 ~2 ~-1 #apocalypse:breakable run setblock ~-1 ~2 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~ ~2 ~1 #apocalypse:breakable run setblock ~ ~2 ~1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~1 ~2 ~1 #apocalypse:breakable run setblock ~1 ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 5 if block ~-1 ~2 ~1 #apocalypse:breakable run setblock ~-1 ~2 ~1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~2 ~ #apocalypse:breakable run setblock ~1 ~2 ~ air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~2 ~1 #apocalypse:breakable run setblock ~1 ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 3 if block ~1 ~2 ~-1 #apocalypse:breakable run setblock ~1 ~2 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-2 ~2 ~ #apocalypse:breakable run setblock ~-1 ~2 ~ air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-1 ~2 ~1 #apocalypse:breakable run setblock ~-1 ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 7 if block ~-1 ~2 ~-1 #apocalypse:breakable run setblock ~-1 ~2 ~-1 air destroy


execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~1 ~2 ~-1 #apocalypse:breakable run setblock ~1 ~2 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~ ~2 ~-1 #apocalypse:breakable run setblock ~ ~2 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 2 if block ~1 ~2 ~ #apocalypse:breakable run setblock ~1 ~2 ~ air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~1 ~2 ~1 #apocalypse:breakable run setblock ~1 ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~ ~2 ~1 #apocalypse:breakable run setblock ~ ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 4 if block ~1 ~2 ~ #apocalypse:breakable run setblock ~1 ~2 ~ air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~-1 ~2 ~1 #apocalypse:breakable run setblock ~-1 ~2 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 6 if block ~ ~2 ~1 #apocalypse:breakable run setblock ~ ~2 ~1 air destroy

execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~ ~2 ~ #apocalypse:breakable run setblock ~ ~2 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~-1 ~2 ~-1 #apocalypse:breakable run setblock ~-1 ~2 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~ ~2 ~-1 #apocalypse:breakable run setblock ~ ~2 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 1 if score @s P_DIRECTION matches 8 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~2 ~ air destroy

#above
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~ ~-1 ~-1 #apocalypse:breakable run setblock ~ ~-1 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~1 ~-1 ~-1 #apocalypse:breakable run setblock ~1 ~-1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 1 if block ~-1 ~-1 ~-1 #apocalypse:breakable run setblock ~-1 ~-1 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~ ~-1 ~1 #apocalypse:breakable run setblock ~ ~-1 ~1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~1 ~-1 ~1 #apocalypse:breakable run setblock ~1 ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 5 if block ~-1 ~-1 ~1 #apocalypse:breakable run setblock ~-1 ~-1 ~1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~-1 ~ #apocalypse:breakable run setblock ~1 ~-1 ~ air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~-1 ~1 #apocalypse:breakable run setblock ~1 ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 3 if block ~1 ~-1 ~-1 #apocalypse:breakable run setblock ~1 ~-1 ~-1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-1 ~ ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-2 ~-1 ~ #apocalypse:breakable run setblock ~-1 ~-1 ~ air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-1 ~-1 ~1 #apocalypse:breakable run setblock ~-1 ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 7 if block ~-1 ~-1 ~-1 #apocalypse:breakable run setblock ~-1 ~-1 ~-1 air destroy


execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~1 ~-1 ~-1 #apocalypse:breakable run setblock ~1 ~-1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~ ~-1 ~-1 #apocalypse:breakable run setblock ~ ~-1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 2 if block ~1 ~-1 ~ #apocalypse:breakable run setblock ~1 ~-1 ~ air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~1 ~-1 ~1 #apocalypse:breakable run setblock ~1 ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~ ~-1 ~1 #apocalypse:breakable run setblock ~ ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 4 if block ~1 ~-1 ~ #apocalypse:breakable run setblock ~1 ~-1 ~ air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~-1 ~-1 ~1 #apocalypse:breakable run setblock ~-1 ~-1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~-1 ~ ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~-2 ~ ~ #apocalypse:breakable run setblock ~-1 ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 6 if block ~ ~-1 ~1 #apocalypse:breakable run setblock ~ ~-1 ~1 air destroy

execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~ ~-1 ~ #apocalypse:breakable run setblock ~ ~-1 ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~-1 ~-1 ~-1 #apocalypse:breakable run setblock ~-1 ~-1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~ ~-1 ~-1 #apocalypse:breakable run setblock ~ ~-1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~-1 ~ ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 2 if score @s P_DIRECTION matches 8 if block ~-2 ~ ~ #apocalypse:breakable run setblock ~-1 ~-1 ~ air destroy



#on level
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 1 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 5 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 3 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-2 ~2 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 7 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy


execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 2 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 4 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 6 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy

execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s ABOVE_BELOW matches 3 if score @s P_DIRECTION matches 8 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy

