

execute if score @s P_DIRECTION matches 1 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 1 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 1 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 1 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy

execute if score @s P_DIRECTION matches 1 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 1 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s P_DIRECTION matches 1 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 1 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy

execute if score @s P_DIRECTION matches 5 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 5 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 5 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 5 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy

execute if score @s P_DIRECTION matches 5 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 5 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s P_DIRECTION matches 5 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 5 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy

execute if score @s P_DIRECTION matches 3 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 3 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 3 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 3 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s P_DIRECTION matches 3 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 3 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s P_DIRECTION matches 3 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 3 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy

execute if score @s P_DIRECTION matches 7 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 7 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 7 if block ~-2 ~2 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy

execute if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 7 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s P_DIRECTION matches 7 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 7 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy


execute if score @s P_DIRECTION matches 2 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 2 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 2 if block ~1 ~1 ~-1 #apocalypse:breakable run setblock ~1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 2 if block ~1 ~ ~-1 #apocalypse:breakable run setblock ~1 ~ ~-1 air destroy
execute if score @s P_DIRECTION matches 2 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 2 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s P_DIRECTION matches 2 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 2 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s P_DIRECTION matches 4 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 4 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 4 if block ~1 ~1 ~1 #apocalypse:breakable run setblock ~1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 4 if block ~1 ~ ~1 #apocalypse:breakable run setblock ~1 ~ ~1 air destroy
execute if score @s P_DIRECTION matches 4 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 4 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy
execute if score @s P_DIRECTION matches 4 if block ~1 ~1 ~ #apocalypse:breakable run setblock ~1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 4 if block ~1 ~ ~ #apocalypse:breakable run setblock ~1 ~ ~ air destroy

execute if score @s P_DIRECTION matches 6 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 6 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~1 #apocalypse:breakable run setblock ~-1 ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 6 if block ~-1 ~ ~1 #apocalypse:breakable run setblock ~-1 ~ ~1 air destroy
execute if score @s P_DIRECTION matches 6 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 6 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy
execute if score @s P_DIRECTION matches 6 if block ~ ~1 ~1 #apocalypse:breakable run setblock ~ ~1 ~1 air destroy
execute if score @s P_DIRECTION matches 6 if block ~ ~ ~1 #apocalypse:breakable run setblock ~ ~ ~1 air destroy

execute if score @s P_DIRECTION matches 8 if block ~ ~1 ~ #apocalypse:breakable run setblock ~ ~1 ~ air destroy
execute if score @s P_DIRECTION matches 8 if block ~ ~ ~ #apocalypse:breakable run setblock ~ ~ ~ air destroy
execute if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~-1 #apocalypse:breakable run setblock ~-1 ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 8 if block ~-1 ~ ~-1 #apocalypse:breakable run setblock ~-1 ~ ~-1 air destroy
execute if score @s P_DIRECTION matches 8 if block ~ ~1 ~-1 #apocalypse:breakable run setblock ~ ~1 ~-1 air destroy
execute if score @s P_DIRECTION matches 8 if block ~ ~ ~-1 #apocalypse:breakable run setblock ~ ~ ~-1 air destroy
execute if score @s P_DIRECTION matches 8 if block ~-1 ~1 ~ #apocalypse:breakable run setblock ~-1 ~1 ~ air destroy
execute if score @s P_DIRECTION matches 8 if block ~-2 ~1 ~ #apocalypse:breakable run setblock ~-1 ~ ~ air destroy