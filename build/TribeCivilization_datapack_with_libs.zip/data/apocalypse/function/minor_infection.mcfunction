effect give @s weakness 40 0 false
effect give @s mining_fatigue 60 0 false
effect give @s hunger 120 0 false
effect give @s slowness 180 0 false
