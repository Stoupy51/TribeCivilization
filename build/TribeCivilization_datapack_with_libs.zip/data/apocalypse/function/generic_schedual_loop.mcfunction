schedule function apocalypse:generic_schedual_loop 62s
effect give @e[type=villager] regeneration 60 0 true
execute if score gbg gb.datapack_detect matches 1 run recipe give @a gbg:medical/minor_infection_cure
