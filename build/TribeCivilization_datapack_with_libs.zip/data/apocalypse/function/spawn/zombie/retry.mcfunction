scoreboard players reset zombie_spawned gbz.temp
function apocalypse:spawn/zombie/spawn_zombie
