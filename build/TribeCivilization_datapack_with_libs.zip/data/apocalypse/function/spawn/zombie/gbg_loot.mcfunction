data merge entity @s[tag=gbz.nurse] {DeathLootTable:"apocalypse:zombie_gbg/nurse_zombie_gbg"}
# If Player only has GBG installed
execute if score pipe_guns gb.datapack_detect matches 0 if score modern_guns gb.datapack_detect matches 0 run data merge entity @s[tag=gbz.gbg_loot] {DeathLootTable:"apocalypse:zombie_gbg/zombie_gbg"}

# If Player has Pipe Guns installed
execute if score pipe_guns gb.datapack_detect matches 1 if score modern_guns gb.datapack_detect matches 0 run data merge entity @s[tag=gbz.gbg_loot] {DeathLootTable:"apocalypse:zombie_gbg/zombie_pipe_guns"}
execute if score pipe_guns gb.datapack_detect matches 1 if score modern_guns gb.datapack_detect matches 0 run data merge entity @s[tag=gbz.scorched] {DeathLootTable:"apocalypse:zombie_gbg/zombie_scorched_pipe_guns"}

# If Player has Modern Guns installed
execute if score modern_guns gb.datapack_detect matches 1 run data merge entity @s[tag=gbz.gbg_loot] {DeathLootTable:"apocalypse:zombie_gbg/zombie_modern_guns"}
execute if score modern_guns gb.datapack_detect matches 1 run data merge entity @s[tag=gbz.scorched] {DeathLootTable:"apocalypse:zombie_gbg/zombie_scorched_modern_guns"}

