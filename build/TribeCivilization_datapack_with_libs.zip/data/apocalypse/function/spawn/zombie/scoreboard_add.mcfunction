scoreboard players set @s[tag=gbz.acid_spitter] gbz.zombie.projectile_damage 3
scoreboard players set @s[tag=gbz.acid_spitter] gbz.zombie.projectile_distance 70
scoreboard players set @s[tag=gbz.acid_spitter] gbz.zombie.projectile_type 1
scoreboard players set @s[tag=gbz.acid_spitter] gbz.zombie.projectile_fire_rate 60
scoreboard players set @s[tag=gbz.acid_spewer] gbz.zombie.projectile_damage 1
scoreboard players set @s[tag=gbz.acid_spewer] gbz.zombie.projectile_distance 40
scoreboard players set @s[tag=gbz.acid_spewer] gbz.zombie.projectile_type 1
scoreboard players set @s[tag=gbz.acid_spewer] gbz.zombie.projectile_fire_rate 25
