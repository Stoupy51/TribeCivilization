attribute @s max_health base set 25
attribute @s movement_speed base set 0.3
attribute @s attack_damage base set 5
attribute @s armor base set 2
