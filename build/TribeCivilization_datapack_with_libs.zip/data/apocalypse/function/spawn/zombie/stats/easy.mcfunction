attribute @s max_health base set 15
attribute @s movement_speed base set 0.25
attribute @s attack_damage base set 3
attribute @s armor base set 0
