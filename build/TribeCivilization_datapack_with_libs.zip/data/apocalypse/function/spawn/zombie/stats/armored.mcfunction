tag @s add gbz.armored
tag @s add gbz.buffed
attribute @s armor modifier add gbz:armored 2 add_value
execute store result score random_armor gbz.temp run random value 1..30
# chestplate and boots 28%
execute if score random_armor gbz.temp matches 1..7 run loot replace entity @s armor.chest loot apocalypse:items/zombie_chestplate
execute if score random_armor gbz.temp matches 1..7 run loot replace entity @s armor.feet loot apocalypse:items/zombie_boots
# leggings and boots 28%
execute if score random_armor gbz.temp matches 8..14 run loot replace entity @s armor.legs loot apocalypse:items/zombie_leggings
execute if score random_armor gbz.temp matches 8..14 run loot replace entity @s armor.feet loot apocalypse:items/zombie_boots
# chestplate only 18%
execute if score random_armor gbz.temp matches 15..20 run loot replace entity @s armor.chest loot apocalypse:items/zombie_chestplate
# leggings only 18%
execute if score random_armor gbz.temp matches 21..25 run loot replace entity @s armor.legs loot apocalypse:items/zombie_leggings
# boots only 8%
execute if score random_armor gbz.temp matches 26..27 run loot replace entity @s armor.feet loot apocalypse:items/zombie_boots
# chestplate and leggings 8%
execute if score random_armor gbz.temp matches 1..7 run loot replace entity @s armor.chest loot apocalypse:items/zombie_chestplate
execute if score random_armor gbz.temp matches 8..14 run loot replace entity @s armor.legs loot apocalypse:items/zombie_leggings
team join gbz_armored_zombie @s

