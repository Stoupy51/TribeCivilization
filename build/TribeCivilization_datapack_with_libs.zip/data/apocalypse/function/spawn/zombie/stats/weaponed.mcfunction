tag @s add gbz.weaponed
tag @s add gbz.buffed
loot replace entity @s weapon.mainhand loot apocalypse:items/zombie_weapon
team join gbz_weaponed_zombie @s
