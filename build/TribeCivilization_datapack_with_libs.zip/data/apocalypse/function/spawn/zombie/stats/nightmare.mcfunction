attribute @s max_health base set 25
attribute @s movement_speed base set 0.3
attribute @s attack_damage base set 6
attribute @s armor base set 2

#stopping function if zombie is the result of a double/triple spawn
execute if entity @s[tag=gbz.extra_zombie] run return 0
## Nightmare Exlusive Modifiers
tag @s add gbz.given_nightmare_stats
execute store result score random_value gbz.temp run random value 1..100
#double zombie 52%
execute if score random_value gbz.temp matches 1..52 run summon zombie ~ ~ ~ {Tags:["gbz.double_spawn","gbz.extra_zombie","gbz.zombie"]}
execute as @e[type=zombie,sort=nearest,limit=1,tag=gbz.double_spawn] at @s run function apocalypse:spawn/zombie/spawn_zombie
#triple zombie 20%
execute if score random_value gbz.temp matches 53..72 run summon zombie ~ ~ ~ {Tags:["gbz.triple_spawn","gbz.extra_zombie","gbz.zombie"]}
execute if score random_value gbz.temp matches 53..72 run summon zombie ~ ~ ~ {Tags:["gbz.triple_spawn","gbz.extra_zombie","gbz.zombie"]}
execute as @e[type=zombie,sort=nearest,limit=2,tag=gbz.triple_spawn] at @s run function apocalypse:spawn/zombie/spawn_zombie
#enraged zombie 7%
execute if score random_value gbz.temp matches 73..80 run function apocalypse:spawn/zombie/stats/enraged
#energized zombie 7%
execute if score random_value gbz.temp matches 80..87 run function apocalypse:spawn/zombie/stats/energized
#armored zombie 7%
execute if score random_value gbz.temp matches 87..94 run function apocalypse:spawn/zombie/stats/armored
#weaponed zombie 7%
execute if score random_value gbz.temp matches 95..100 unless entity @s[tag=gbz.weaponed] run function apocalypse:spawn/zombie/stats/weaponed

