attribute @s max_health base set 20
attribute @s movement_speed base set 0.3
attribute @s attack_damage base set 4
attribute @s armor base set 0
