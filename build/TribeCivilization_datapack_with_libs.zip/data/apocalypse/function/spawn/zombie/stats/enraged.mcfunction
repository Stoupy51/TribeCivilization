tag @s add gbz.enraged
tag @s add gbz.buffed
attribute @s armor modifier add gbz:enraged 3 add_value
attribute @s attack_damage modifier add gbz:enraged 3 add_value
team join gbz_enraged_zombie @s
