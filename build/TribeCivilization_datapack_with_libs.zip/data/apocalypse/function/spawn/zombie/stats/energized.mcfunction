tag @s add gbz.energized
tag @s add gbz.buffed
attribute @s attack_damage modifier add gbz:energized 1 add_value
attribute @s movement_speed modifier add gbz:energized 0.06 add_value
team join gbz_energized_zombie @s
