execute if score zombie_villager_toggle config.gbz matches 1 run return 1
summon zombie_villager ~ ~ ~ {CanBreakDoors:1b,CanPickUpLoot:1b,DeathLootTable:"apocalypse:zombie/zombie_villager",Tags:["gbz.zombie"],ArmorItems:[{},{},{},{id:"minecraft:stone_button",count:1}],ArmorDropChances:[0.000F,0.000F,0.000F,0.000F]}
