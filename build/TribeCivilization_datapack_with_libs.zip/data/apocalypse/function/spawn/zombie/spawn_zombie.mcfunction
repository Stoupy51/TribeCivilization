# Spawning Zombie
execute store result score zombie_type_temp gbz.temp run random value 1..100
execute if score zombie_type_temp gbz.temp matches 1..50 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/swarm
execute if score zombie_type_temp gbz.temp matches 51..57 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/nurse
execute if score zombie_type_temp gbz.temp matches 58..63 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/psychopath
execute if score zombie_type_temp gbz.temp matches 64..69 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/miner
execute if score zombie_type_temp gbz.temp matches 70..75 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/builder
execute if score zombie_type_temp gbz.temp matches 76..81 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/acid_spitter
execute if score zombie_type_temp gbz.temp matches 82..89 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/scorched
execute if score zombie_type_temp gbz.temp matches 90..96 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/acid_spewer
execute if score zombie_type_temp gbz.temp matches 97..98 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/dj
execute if score zombie_type_temp gbz.temp matches 99..100 store result score zombie_spawned gbz.temp run function apocalypse:spawn/zombie/zombies/zombie_villager
execute if score zombie_spawned gbz.temp matches 1 run return run function apocalypse:spawn/zombie/retry

# Changing Loot table if playing with GBG
execute if score gbg gb.datapack_detect matches 1 as @e[type=zombie,tag=gbz.zombie,sort=nearest,limit=1] at @s run function apocalypse:spawn/zombie/gbg_loot

# Setting Scoreboards for Applicable Zombies
scoreboard players add @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.scoreboard_timer,distance=..1,limit=2,sort=nearest] gbz.ability_timer 0
execute as @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.shooter,distance=..1,limit=2,sort=nearest] run function apocalypse:spawn/zombie/scoreboard_add

# Setting Stats Depending on the Difficulty
#Easy
execute if score current_difficulty gbz.difficulty matches 1 as @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.zombie,sort=nearest,limit=2] at @s run function apocalypse:spawn/zombie/stats/easy
#Normal
execute if score current_difficulty gbz.difficulty matches 2 as @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.zombie,sort=nearest,limit=2] at @s run function apocalypse:spawn/zombie/stats/normal
#Hard
execute if score current_difficulty gbz.difficulty matches 3 as @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.zombie,sort=nearest,limit=2] at @s run function apocalypse:spawn/zombie/stats/hard
#Nightmare
execute if entity @s[tag=gbz.extra_zombie] run tag @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.zombie,sort=nearest,limit=2] add gbz.extra_zombie
execute if score current_difficulty gbz.difficulty matches 4 as @e[type=zombie,tag=!gbz.given_nightmare_stats,tag=gbz.zombie,sort=nearest,limit=2] at @s run function apocalypse:spawn/zombie/stats/nightmare

# Killing Orgiginal Mob
tag @s add zombie
tp @s ~ ~-256 ~
kill @s
