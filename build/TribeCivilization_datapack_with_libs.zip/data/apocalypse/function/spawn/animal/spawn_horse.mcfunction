# If matches 0
execute if entity @e[type=player,distance=40..] if score horse gbz.zombie_spawning_loop matches 0 run summon zombie_horse ~ ~ ~ {DeathLootTable:"apocalypse:zombie_animal/zombie_horse",Tame:1b,Tags:["gbz.zombie"]}
execute if entity @e[type=player,distance=40..] if score horse gbz.zombie_spawning_loop matches 0 run tp @s ~ ~-256 ~
execute if entity @e[type=player,distance=..0.5] if score horse gbz.zombie_spawning_loop matches 0 run summon zombie_horse ~ ~ ~ {DeathLootTable:"apocalypse:zombie_animal/zombie_horse",Tame:1b,Tags:["gbz.zombie"]}
execute if entity @e[type=player,distance=..0.5] if score horse gbz.zombie_spawning_loop matches 0 run tp @s ~ ~-256 ~

# Always
tag @s add gbz.zombie
scoreboard players add horse gbz.zombie_spawning_loop 1
execute if score horse gbz.zombie_spawning_loop matches 5 run scoreboard players set horse gbz.zombie_spawning_loop 0
