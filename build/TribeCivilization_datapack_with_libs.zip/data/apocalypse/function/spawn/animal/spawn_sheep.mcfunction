## If matches 0
execute if entity @e[type=player,distance=40..] if score sheep gbz.zombie_spawning_loop matches 0..1 run summon sheep ~ ~ ~ {CustomName:'{"text":"Zombie Sheep"}',DeathLootTable:"apocalypse:zombie_animal/zombie_sheep",PersistenceRequired:1b,Tags:["gbz.zombie","sheep_zombie","zombie_animal"],Passengers:[{CustomName:'{"text":"Zombie Sheep"}',id:"minecraft:husk",Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["sheep_brain","gbz.zombie","zombie_animal_brain"],active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],CustomName:'{"text":"Zombie Sheep"}',attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=40..] if score sheep gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~
execute if entity @e[type=player,distance=..0.5] if score sheep gbz.zombie_spawning_loop matches 0..1 run summon sheep ~ ~ ~ {CustomName:'{"text":"Zombie Sheep"}',DeathLootTable:"apocalypse:zombie_animal/zombie_sheep",PersistenceRequired:1b,Tags:["gbz.zombie","sheep_zombie","zombie_animal"],Passengers:[{CustomName:'{"text":"Zombie Sheep"}',id:"minecraft:husk",Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["sheep_brain","gbz.zombie","zombie_animal_brain"],active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],CustomName:'{"text":"Zombie Sheep"}',attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=..0.5] if score sheep gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~

# Always
tag @s add gbz.zombie
scoreboard players add sheep gbz.zombie_spawning_loop 1
execute if score sheep gbz.zombie_spawning_loop matches 3 run scoreboard players set sheep gbz.zombie_spawning_loop 0
