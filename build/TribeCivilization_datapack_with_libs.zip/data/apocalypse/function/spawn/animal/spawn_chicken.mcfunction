# If matches 0
execute if entity @e[type=player,distance=40..] if score chicken gbz.zombie_spawning_loop matches 0..1 run summon chicken ~ ~ ~ {CustomName:'{"text":"Zombie Chicken"}',DeathLootTable:"apocalypse:zombie_animal/zombie_chicken",PersistenceRequired:1b,Tags:["gbz.zombie","chicken_zombie","zombie_animal"],Passengers:[{id:"minecraft:husk",Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["chicken_brain","gbz.zombie","zombie_animal_brain"],CustomName:'{"text":"Zombie Chicken"}',active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=40..] if score chicken gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~
execute if entity @e[type=player,distance=..0.5] if score chicken gbz.zombie_spawning_loop matches 0..1 run summon chicken ~ ~ ~ {CustomName:'{"text":"Zombie Chicken"}',DeathLootTable:"apocalypse:zombie_animal/zombie_chicken",PersistenceRequired:1b,Tags:["gbz.zombie","chicken_zombie","zombie_animal"],Passengers:[{id:"minecraft:husk",Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["chicken_brain","gbz.zombie","zombie_animal_brain"],CustomName:'{"text":"Zombie Chicken"}',active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=..0.5] if score chicken gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~

# Always
tag @s add gbz.zombie
scoreboard players add chicken gbz.zombie_spawning_loop 1
execute if score chicken gbz.zombie_spawning_loop matches 3 run scoreboard players set chicken gbz.zombie_spawning_loop 0

