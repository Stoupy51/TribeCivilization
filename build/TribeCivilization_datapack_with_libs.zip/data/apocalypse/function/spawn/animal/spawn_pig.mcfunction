# If matches 0
execute if entity @e[type=player,distance=40..] if score pig gbz.zombie_spawning_loop matches 0..1 run summon pig ~ ~ ~ {CustomName:'{"text":"Zombie Pig"}',DeathLootTable:"apocalypse:zombie_animal/zombie_pig",PersistenceRequired:1b,Tags:["gbz.zombie","pig_zombie","zombie_animal"],Passengers:[{id:"minecraft:husk",CustomName:'{"text":"Zombie Pig"}',Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["pig_brain","gbz.zombie","zombie_animal_brain"],active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],CustomName:'{"text":"Zombie Pig"}',attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=40..] if score pig gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~
execute if entity @e[type=player,distance=..0.5] unless entity @s[tag=turret] if score pig gbz.zombie_spawning_loop matches 0..1 run summon pig ~ ~ ~ {CustomName:'{"text":"Zombie Pig"}',DeathLootTable:"apocalypse:zombie_animal/zombie_pig",PersistenceRequired:1b,Tags:["gbz.zombie","pig_zombie","zombie_animal"],Passengers:[{id:"minecraft:husk",CustomName:'{"text":"Zombie Pig"}',Silent:1b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:1b,CanPickUpLoot:0b,IsBaby:0b,CanBreakDoors:0b,Tags:["pig_brain","gbz.zombie","zombie_animal_brain"],active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1000000,show_particles:0b}],CustomName:'{"text":"Zombie Pig"}',attributes:[{id:"minecraft:scale",base:0.1}]}]}
execute if entity @e[type=player,distance=..0.5] unless entity @s[tag=turret] if score pig gbz.zombie_spawning_loop matches 0..1 run tp @s ~ ~-256 ~

# Always
#all pigs need to be identified as pigs because of the GBG turrets
tag @s add a_literal_pig
tag @s add gbz.zombie
scoreboard players add pig gbz.zombie_spawning_loop 1
execute if score pig gbz.zombie_spawning_loop matches 3 run scoreboard players set pig gbz.zombie_spawning_loop 0

