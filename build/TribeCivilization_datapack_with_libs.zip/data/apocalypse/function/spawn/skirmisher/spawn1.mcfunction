# Determining which direction they should come from
execute store result score skirmisher gbz.random_roll run random value 1..4

# Spawning the right one
execute if score skirmisher gbz.random_roll matches 1 run summon marker ~65 ~ ~ {Tags:["skirmisher_spawner"]}
execute if score skirmisher gbz.random_roll matches 2 run summon marker ~-65 ~ ~ {Tags:["skirmisher_spawner"]}
execute if score skirmisher gbz.random_roll matches 3 run summon marker ~ ~ ~65 {Tags:["skirmisher_spawner"]}
execute if score skirmisher gbz.random_roll matches 4 run summon marker ~ ~ ~-65 {Tags:["skirmisher_spawner"]}

# getting current player pos
execute store result score x gbz.location run data get entity @s Pos[0]
execute store result score y gbz.location run data get entity @s Pos[1]
execute store result score z gbz.location run data get entity @s Pos[2]

execute store result storage gbz:macro location.target_x float 1 run scoreboard players get x gbz.location
execute store result storage gbz:macro location.target_y float 1 run scoreboard players get y gbz.location
execute store result storage gbz:macro location.target_z float 1 run scoreboard players get z gbz.location

# second half of spawning system
execute as @e[type=marker,tag=skirmisher_spawner] at @s run function apocalypse:spawn/skirmisher/spawn2 with storage gbz:macro location

