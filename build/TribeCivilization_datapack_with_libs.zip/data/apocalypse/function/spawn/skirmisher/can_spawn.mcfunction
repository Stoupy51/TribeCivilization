# Getting time of day
execute store result score gbz.day_time gbz.day_time run time query daytime
# Increasing timer if it's night and then stopping the function
execute if score gbz.day_time gbz.day_time matches 13700..22600 store result score gbz.illager_spawner gbz.illager_spawner run random value 5050..7200
execute if score gbz.illager_spawner gbz.illager_spawner matches 13700.. run return fail
# At the position of a random player, spawning the skirmish
execute if score skirmisher_toggle config.gbz matches 0 as @a[sort=random,limit=1] at @s run function apocalypse:spawn/skirmisher/spawn1
# Setting timer to high value
execute store result score gbz.illager_spawner gbz.illager_spawner run random value 72000..144000
