#Reseting Player Death Scoreboard
scoreboard players set @s gbz.player_death 0

## Stopping Function
# There isn't a zombie close by
execute unless entity @e[type=#apocalypse:is_zombie,distance=..3] run return fail
# Player zombies are turned off
execute unless score player_zombies_toggle config.gbz matches 0 run return fail
# More than 4 player zombies are nearby
scoreboard players set player_zombie_count gbz.temp 0
execute store result score player_zombie_count gbz.temp if entity @e[type=zombie,tag=gbz.player_zombie,limit=4,sort=nearest,distance=..20]
execute if score player_zombie_count gbz.temp matches 4.. run return fail

## Spawning Player Zombie
# Spawning the Zombie
summon zombie ~ ~ ~ {DeathLootTable:"minecraft:empty",Team:"gbz_player_zombie",PersistenceRequired:1b,CanPickUpLoot:1b,Health:30f,IsBaby:0b,CanBreakDoors:1b,Tags:["gbz.zombie","gbz.player_zombie","no_head"],CustomName:'{"text":"Player Zombie","color":"yellow"}',attributes:[{id:max_health,base:30},{id:movement_speed,base:0.32},{id:attack_damage,base:6}]}
# Setting stats for Player Zombie
execute as @e[type=zombie,tag=no_head,distance=..2] at @s run function apocalypse:spawn/player_zombie/stats/sort
# Giving Player Zombie its Head
loot replace entity @e[type=zombie,tag=no_head,distance=..2] armor.head loot apocalypse:player_head
# Setting Player Zombie Name to be Dead Player Name
setblock ~ -63 ~ oak_sign{front_text:{messages:['{"nbt":"ArmorItems[3].components.minecraft:profile.name","entity":"@e[type=zombie,limit=1,tag=no_head,sort=nearest]"}','{"text":""}','{"text":""}','{"text":""}']}} replace
data modify entity @e[type=zombie,limit=1,tag=no_head] CustomName set from block ~ -63 ~ front_text.messages[0]
setblock ~ -63 ~ bedrock
# Making sure this zombie won't get stuff again in the future
tag @e[type=zombie,tag=no_head,distance=..2] remove no_head

