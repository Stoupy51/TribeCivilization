execute if score current_difficulty gbz.difficulty matches 1 run function apocalypse:spawn/player_zombie/stats/easy
execute if score current_difficulty gbz.difficulty matches 2 run function apocalypse:spawn/player_zombie/stats/normal
execute if score current_difficulty gbz.difficulty matches 3..4 run function apocalypse:spawn/player_zombie/stats/hard
