attribute @s max_health base set 35
attribute @s movement_speed base set 0.32
attribute @s attack_damage base set 6
attribute @s armor base set 2
