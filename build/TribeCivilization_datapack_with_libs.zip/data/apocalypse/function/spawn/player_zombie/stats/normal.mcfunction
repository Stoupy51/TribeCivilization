attribute @s max_health base set 30
attribute @s movement_speed base set 0.31
attribute @s attack_damage base set 5
attribute @s armor base set 0
