schedule function apocalypse:zombie_attributes_loop 2s
#Zombie Fire Weakness
execute as @s[type=zombie,predicate=apocalypse:is_burning,tag=!gbz.scorched] run function apocalypse:zombie_on_fire
#Water Zombie Movement Speed Changes
execute as @s[type=drowned,tag=gbz.water_zombie] if block ~ ~ ~ #apocalypse:water run attribute @s movement_speed base set 0.85
execute as @s[type=drowned,tag=gbz.water_zombie] unless block ~ ~ ~ #apocalypse:water run attribute @s movement_speed base set 0.3
