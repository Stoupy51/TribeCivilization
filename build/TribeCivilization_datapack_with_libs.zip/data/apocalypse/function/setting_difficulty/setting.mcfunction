# If difficulty has already been set
execute unless score current_difficulty gbz.difficulty matches 0 run return run tellraw @s ["",{"text":"The difficulty has already been set for this world.","color":"#97E46F"},{"text":"\n"},{"text":"You can change it via the config menu:","bold":true,"color":"#8FE38E"},{"text":"\n"},{"text":"/","color":"#D5C8DE"},{"text":"function","color":"#C586C0"},{"text":" config:gbz","color":"#DCDCAA"}]

# Easy
execute if score @s gbz.difficulty matches 1 run scoreboard players set current_difficulty gbz.difficulty 1
execute if score @s gbz.difficulty matches 1 run tellraw @a ["",{"text":"GBZ difficulty has been set to "},{"text":"Easy","color":"green"}]

# Normal
execute if score @s gbz.difficulty matches 2 run scoreboard players set current_difficulty gbz.difficulty 2
execute if score @s gbz.difficulty matches 2 run tellraw @a ["",{"text":"GBZ difficulty has been set to "},{"text":"Normal","color":"gold"}]

# Hard
execute if score @s gbz.difficulty matches 3 run scoreboard players set current_difficulty gbz.difficulty 3
execute if score @s gbz.difficulty matches 3 run tellraw @a ["",{"text":"GBZ difficulty has been set to "},{"text":"Hard","color":"red"}]

# Nightmare
execute if score @s gbz.difficulty matches 4 run scoreboard players set current_difficulty gbz.difficulty 4
execute if score @s gbz.difficulty matches 4 run tellraw @a ["",{"text":"GBZ difficulty has been set to "},{"text":"Nightmare","color":"dark_red"}]

