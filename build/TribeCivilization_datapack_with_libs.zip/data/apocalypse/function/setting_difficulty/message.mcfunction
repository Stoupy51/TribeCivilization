execute unless score current_difficulty gbz.difficulty matches 0 run return fail
execute if score current_difficulty gbz.difficulty matches 0 run schedule function apocalypse:setting_difficulty/message 20s replace
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a {"text":""}
tellraw @a ["",{"text":"Welcome To ","color":"#D9E9F4"},{"text":"Gamingbarn's Zombies","underlined":true,"color":"#7067FE","clickEvent":{"action":"open_url","value":"https://modrinth.com/datapack/gamingbarns-zombies"}},{"text":"\n"},{"text":"Please choose your difficulty","color":"#9CC3C7"},{"text":"\n"},{"text":"[Easy]","color":"green","clickEvent":{"action":"run_command","value":"/trigger gbz.difficulty set 1"},"hoverEvent":{"action":"show_text","contents":"While faster than in vanilla, zombies are very weak. Minor Infection has a reduced chance."}},{"text":" "},{"text":"[Normal]","color":"gold","clickEvent":{"action":"run_command","value":"/trigger gbz.difficulty set 2"},"hoverEvent":{"action":"show_text","contents":"The standard GBZ experience."}},{"text":" "},{"text":"[Hard]","color":"red","clickEvent":{"action":"run_command","value":"/trigger gbz.difficulty set 3"},"hoverEvent":{"action":"show_text","contents":"Zombies are tougher than normal. Minor Infection has an increased chance."}},{"text":"\n"},{"text":"[Nightmare]","color":"dark_red","clickEvent":{"action":"run_command","value":"/trigger gbz.difficulty set 4"},"hoverEvent":{"action":"show_text","contents":"Zombies are stronger, spawn more often, and have powerful variants. A true test of your skill."}},{"text":" "},{"text":"[Mutation]","color":"#31373E","hoverEvent":{"action":"show_text","contents":"Still in development. Not yet available."}}]
