execute as @a at @s as @e[type=zombie,sort=nearest,limit=2] run damage @s 1 generic by @p

say angry
# Rescheduling
#schedule function apocalypse:anger 20s


