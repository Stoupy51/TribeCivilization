## Abilities
# Shooter Zombie
scoreboard players remove @s[type=#apocalypse:is_zombie,scores={gbz.ability_timer=1..}] gbz.ability_timer 1
execute as @s[type=#apocalypse:is_zombie,tag=gbz.shooter,scores={gbz.ability_timer=0}] if entity @e[type=#apocalypse:zombie_targets,distance=..5] anchored eyes facing entity @e[type=#apocalypse:zombie_targets,distance=..5,limit=1,sort=nearest] eyes run function apocalypse:zombie_abilities/projectile/shoot
execute as @s[type=zombie,tag=gbz.acid_spitter] if entity @e[type=#apocalypse:zombie_targets,distance=..7] run effect give @s slowness 1 4 true
execute as @s[type=zombie,tag=gbz.acid_spewer] if entity @e[type=#apocalypse:zombie_targets,distance=..4] run effect give @s slowness 1 2 true

# Builder and Miner
execute as @s[type=zombie,tag=gbz.modifier,scores={gbz.ability_timer=0}] if entity @e[type=player,distance=..48] run function apocalypse:zombie_abilities/get_direction

# Nurse Zombie
execute as @s[type=zombie,tag=gbz.nurse,scores={gbz.ability_timer=0}] if entity @e[type=player,distance=..26] run function apocalypse:zombie_abilities/nurse/nurse

