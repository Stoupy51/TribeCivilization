advancement revoke @s only apocalypse:eat_raw_beef
effect give @s hunger 10 0 true
