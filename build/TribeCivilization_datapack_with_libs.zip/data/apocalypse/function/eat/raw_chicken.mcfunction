advancement revoke @s only apocalypse:eat_raw_chicken
effect give @s hunger 15 1 true
