advancement revoke @s only apocalypse:eat_rotten_flesh
effect give @s hunger 30 1 true
