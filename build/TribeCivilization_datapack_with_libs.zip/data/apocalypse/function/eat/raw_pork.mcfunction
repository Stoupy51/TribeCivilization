advancement revoke @s only apocalypse:eat_raw_pork
effect give @s hunger 20 1 true
