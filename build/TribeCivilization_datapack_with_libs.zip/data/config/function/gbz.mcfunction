# Only runs when the player directly calls the function
tellraw @s ["------- ",{"text":"GBZ Config Menu","color":"gold", "bold":true}," -------"]

tellraw @s ["--- ",{"text":"Difficulty","color":"#f6d253"}," ---"]


execute if score current_difficulty gbz.difficulty matches 1 run tellraw @a ["",{"text":"[Easy]","bold":true,"color":"green","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/easy"}},{"text":" "},{"text":"[Normal]","color":"#988054","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/normal"}},{"text":" ","color":"gray"},{"text":"[Hard]","color":"#B26C75","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/hard"}}]
execute if score current_difficulty gbz.difficulty matches 2 run tellraw @a ["",{"text":"[Easy]","color":"#92c188","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/easy"}},{"text":" "},{"text":"[Normal]","color":"gold","bold":true,"clickEvent":{"action":"run_command","value":"/function config:z/difficulty/normal"}},{"text":" ","color":"gray"},{"text":"[Hard]","color":"#B26C75","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/hard"}}]
execute if score current_difficulty gbz.difficulty matches 3 run tellraw @a ["",{"text":"[Easy]","color":"#92c188","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/easy"}},{"text":" "},{"text":"[Normal]","color":"#988054","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/normal"}},{"text":" ","color":"gray"},{"text":"[Hard]","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"/function config:z/difficulty/hard"}}]
execute if score current_difficulty gbz.difficulty matches 4.. run tellraw @a ["",{"text":"[Easy]","color":"#92c188","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/easy"}},{"text":" "},{"text":"[Normal]","color":"#988054","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/normal"}},{"text":" ","color":"gray"},{"text":"[Hard]","color":"#B26C75","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/hard"}}]

execute if score current_difficulty gbz.difficulty matches ..3 run tellraw @a ["",{"text":"[☠ Nightmare ☠]","color":"#5A3435","clickEvent":{"action":"run_command","value":"/function config:z/difficulty/nightmare"}},{"text":" "},{"text":"[🏃 Mutation 🏃]","color":"#1b1f24","hoverEvent":{"action":"show_text","contents":"Still in development"}}]
execute if score current_difficulty gbz.difficulty matches 4 run tellraw @a ["",{"text":"[☠ Nightmare ☠]","color":"dark_red","bold":true,"clickEvent":{"action":"run_command","value":"/function config:z/difficulty/nightmare"}},{"text":" "},{"text":"[🏃 Mutation 🏃]","color":"#1b1f24","hoverEvent":{"action":"show_text","contents":"Still in development"}}]


tellraw @s ["--- ",{"text":"Mob Spawning","color":"#f6d253"}," ---"]

execute if score swarm_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/swarm_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Swarm Zombie"]
execute if score swarm_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/swarm_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Swarm Zombie"]

execute if score acid_spewer_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/acid_spewer_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Acid Spewer"]
execute if score acid_spewer_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/acid_spewer_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Acid Spewer"]

execute if score acid_spitter_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/acid_spitter_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Acid Spitter"]
execute if score acid_spitter_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/acid_spitter_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Acid Spitter"]

execute if score builder_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/builder_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Builder Zombie"]
execute if score builder_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/builder_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Builder Zombie"]

execute if score miner_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/miner_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Miner Zombie"]
execute if score miner_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/miner_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Miner Zombie"]

execute if score nurse_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/nurse_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Nurse Zombie"]
execute if score nurse_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/nurse_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Nurse Zombie"]

execute if score psycho_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/psycho_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Psychopath Zombie"]
execute if score psycho_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/psycho_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Psychopath Zombie"]

execute if score scorched_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/scorched_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Scorched Zombie"]
execute if score scorched_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/scorched_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Scorched Zombie"]

execute if score dj_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/dj_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," DJ Zombie"]
execute if score dj_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/dj_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," DJ Zombie"]

execute if score zombie_villager_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/zombie_villager_off"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"green"}," Zombie Villager"]
execute if score zombie_villager_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/zombie_villager_on"},"hoverEvent":{"action":"show_text","contents":"Change this zombie's ability to spawn naturally."},"color":"red"}," Zombie Villager"]

execute if score animal_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/animal_zombies_off"},"hoverEvent":{"action":"show_text","contents":"Change whether or not zombified animals will spawn."},"color":"green"}," Zombie Animals"]
execute if score animal_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/animal_zombies_on"},"hoverEvent":{"action":"show_text","contents":"Change whether or not zombified animals will spawn."},"color":"red"}," Zombie Animals"]

execute if score player_zombies_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/player_zombies_off"},"hoverEvent":{"action":"show_text","contents":"Change whether players spawn zombies upon death to a zombie."},"color":"green"}," Player Zombies"]
execute if score player_zombies_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/player_zombies_on"},"hoverEvent":{"action":"show_text","contents":"Change whether players spawn zombies upon death to a zombie."},"color":"red"}," Player Zombies"]

execute if score skirmisher_toggle config.gbz matches 0 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/skirmisher_off"},"hoverEvent":{"action":"show_text","contents":"Change if Illager Skirmishes will spawn occasionally."},"color":"green"}," Illager Skirmishes"]
execute if score skirmisher_toggle config.gbz matches 1 run tellraw @s ["",{"text":"[O]","clickEvent":{"action":"run_command","value":"/function config:z/skirmisher_on"},"hoverEvent":{"action":"show_text","contents":"hange if Illager Skirmishes will spawn occasionally."},"color":"red"}," Illager Skirmishes"]

tellraw @s ["-----------------------------"]
