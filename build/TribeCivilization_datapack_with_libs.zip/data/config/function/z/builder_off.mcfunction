scoreboard players set builder_toggle config.gbz 1
function config:gbz