scoreboard players set psycho_toggle config.gbz 0
function config:gbz