scoreboard players set skirmisher_toggle config.gbz 0
function config:gbz