scoreboard players set current_difficulty gbz.difficulty 3
function config:gbz
