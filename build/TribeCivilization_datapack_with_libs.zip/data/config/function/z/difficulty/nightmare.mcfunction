scoreboard players set current_difficulty gbz.difficulty 4
function config:gbz
