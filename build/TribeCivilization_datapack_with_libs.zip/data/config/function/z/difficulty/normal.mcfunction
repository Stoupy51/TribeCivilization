scoreboard players set current_difficulty gbz.difficulty 2
function config:gbz

