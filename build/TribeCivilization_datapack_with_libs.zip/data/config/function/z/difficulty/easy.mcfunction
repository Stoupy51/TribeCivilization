scoreboard players set current_difficulty gbz.difficulty 1
function config:gbz
