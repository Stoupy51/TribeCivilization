scoreboard players set dj_toggle config.gbz 0
function config:gbz