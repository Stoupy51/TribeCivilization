scoreboard players set player_zombies_toggle config.gbz 1
function config:gbz