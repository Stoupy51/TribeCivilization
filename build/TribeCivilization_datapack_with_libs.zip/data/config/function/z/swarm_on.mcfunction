scoreboard players set swarm_toggle config.gbz 0
function config:gbz