scoreboard players set swarm_toggle config.gbz 1
function config:gbz