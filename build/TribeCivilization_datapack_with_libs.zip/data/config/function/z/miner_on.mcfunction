scoreboard players set miner_toggle config.gbz 0
function config:gbz