scoreboard players set zombie_villager_toggle config.gbz 0
function config:gbz