scoreboard players set animal_toggle config.gbz 0
function config:gbz