scoreboard players set nurse_toggle config.gbz 1
function config:gbz