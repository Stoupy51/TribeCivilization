scoreboard players set builder_toggle config.gbz 0
function config:gbz