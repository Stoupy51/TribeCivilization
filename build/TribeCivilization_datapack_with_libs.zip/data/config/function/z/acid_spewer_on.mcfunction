scoreboard players set acid_spewer_toggle config.gbz 0
function config:gbz