scoreboard players set scorched_toggle config.gbz 1
function config:gbz