scoreboard players set nurse_toggle config.gbz 0
function config:gbz