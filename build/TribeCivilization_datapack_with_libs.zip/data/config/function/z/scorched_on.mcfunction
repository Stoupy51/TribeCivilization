scoreboard players set scorched_toggle config.gbz 0
function config:gbz