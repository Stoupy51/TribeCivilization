scoreboard players set acid_spitter_toggle config.gbz 1
function config:gbz