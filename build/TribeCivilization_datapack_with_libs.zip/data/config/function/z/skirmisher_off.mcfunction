scoreboard players set skirmisher_toggle config.gbz 1
function config:gbz