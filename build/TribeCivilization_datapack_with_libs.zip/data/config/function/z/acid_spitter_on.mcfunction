scoreboard players set acid_spitter_toggle config.gbz 0
function config:gbz