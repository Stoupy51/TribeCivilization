scoreboard players set acid_spewer_toggle config.gbz 1
function config:gbz