scoreboard players set zombie_villager_toggle config.gbz 1
function config:gbz