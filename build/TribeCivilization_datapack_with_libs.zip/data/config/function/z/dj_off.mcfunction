scoreboard players set dj_toggle config.gbz 1
function config:gbz