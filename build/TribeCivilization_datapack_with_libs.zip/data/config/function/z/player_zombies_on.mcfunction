scoreboard players set player_zombies_toggle config.gbz 0
function config:gbz