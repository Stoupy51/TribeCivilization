scoreboard players set animal_toggle config.gbz 1
function config:gbz