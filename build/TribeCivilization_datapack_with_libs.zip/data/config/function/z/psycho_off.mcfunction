scoreboard players set psycho_toggle config.gbz 1
function config:gbz