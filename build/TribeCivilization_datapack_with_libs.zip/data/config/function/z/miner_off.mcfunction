scoreboard players set miner_toggle config.gbz 1
function config:gbz