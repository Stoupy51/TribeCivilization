
#> iyc:calls/simpledrawer/topaz/block
#
# @within	iyc:calls/simpledrawer/material
#

scoreboard players set #type simpledrawer.io 0
function iyc:calls/simpledrawer/topaz/main